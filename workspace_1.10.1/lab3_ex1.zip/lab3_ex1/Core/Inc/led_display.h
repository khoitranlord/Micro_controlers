/*
 * led_display.h
 *
 *  Created on: Nov 2, 2022
 *      Author: AdminPC
 */

#ifndef INC_LED_DISPLAY_H_
#define INC_LED_DISPLAY_H_

void display7SEG(int counter);

void updateClockBuffer(int minute, int hour);


#endif /* INC_LED_DISPLAY_H_ */
