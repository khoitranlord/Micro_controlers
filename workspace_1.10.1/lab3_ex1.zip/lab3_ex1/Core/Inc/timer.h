/*
 * timer.h
 *
 *  Created on: Nov 2, 2022
 *      Author: AdminPC
 */

#ifndef INC_TIMER_H_
#define INC_TIMER_H_

extern int timer1_flag;

void setTimer(int duration);

void timerRun();

#endif /* INC_TIMER_H_ */
