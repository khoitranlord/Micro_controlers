/*
 * global.h
 *
 *  Created on: Nov 2, 2022
 *      Author: AdminPC
 */

#ifndef INC_GLOBAL_H_
#define INC_GLOBAL_H_

#include "main.h"
#include "timer.h"
#include "main.h"
#include "fsm_automatic.h"
#include "fsm_manual.h"
#include "ports.h"
#include "input_reading.h"
#include "input_processing.h"
#include "led_display.h"

//led_variables
const int MAX_LED = 4;
int led_buffer[4];
extern int mode;
extern int red_duration;
extern int yellow_duration;
extern int green_duration;


#define INIT		1
#define MAN_RED		2
#define MAN_YELLOW	3
#define MAN_GREEN 	4
#define RED_GREEN	5
#define RED_YELLOW	6
#define GREEN_RED	7
#define YELLOW_RED 	8
extern int status;

#endif /* INC_GLOBAL_H_ */
