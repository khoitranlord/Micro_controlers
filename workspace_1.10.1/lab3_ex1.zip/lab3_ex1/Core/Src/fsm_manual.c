/*
 * fsm_manual.c
 *
 *  Created on: Nov 2, 2022
 *      Author: AdminPC
 */

#include "fsm_manual.h"
#include "global.h"

void fsm_manual_run()
{
	switch (status)
	{
	case MAN_RED:
		HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(LED_YELLOW_GPIO_Port, LED_YELLOW_Pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, GPIO_PIN_SET);
		int red_duration_tmp = 0;
		if (timer1_flag == 1) status = INIT;
		if (is_button_pressed(1) == 1){
			red_duration_tmp ++;
			updateClockBuffer(2, red_duration_tmp);
			if(is_button_pressed(2)){
				red_duration = red_duration_tmp;
				status = INIT;
			}
		}
		if (is_button_pressed(1) == 1)
		{
			status = MAN_YELLOW;

			setTimer(1000);

		}
		break;
	case MAN_YELLOW:
		HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(LED_YELLOW_GPIO_Port, LED_YELLOW_Pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, GPIO_PIN_SET);
		if (is_button_pressed(1) == 1)
		{
			status = MAN_GREEN;
			setTimer(1000);
		}
		break;

	case MAN_GREEN:
		HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(LED_YELLOW_GPIO_Port, LED_YELLOW_Pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, GPIO_PIN_RESET);
		if (is_button_pressed(1) == 1)
		{
			status = INIT;
			setTimer(1000);
		};

		break;
	default:
		break;
	}
}
