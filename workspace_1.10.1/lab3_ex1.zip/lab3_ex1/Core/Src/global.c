/*
 * global.c
 *
 *  Created on: Nov 2, 2022
 *      Author: AdminPC
 */
#include "global.h"

int status = INIT;
int mode = 1;
int red_duration = 5;
int yellow_duration = 2;
int green_duration = 3;

