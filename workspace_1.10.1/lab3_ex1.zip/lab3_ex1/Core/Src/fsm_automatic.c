/*
 * fsm_automatic.c
 *
 *  Created on: Nov 2, 2022
 *      Author: AdminPC
 */
#include "global.h"
#include "fsm_automatic.h"
#include "input_processing.h"

extern int status;

void fsm_automatic_run(){
	switch(status){
	case INIT:
		  HAL_GPIO_WritePin ( LED_RED_GPIO_Port , LED_RED_Pin ,GPIO_PIN_SET );
		  HAL_GPIO_WritePin ( LED_YELLOW_GPIO_Port , LED_YELLOW_Pin ,GPIO_PIN_SET );
		  HAL_GPIO_WritePin ( LED_GREEN_GPIO_Port , LED_GREEN_Pin ,GPIO_PIN_SET );
		  HAL_GPIO_WritePin ( LED_RED1_GPIO_Port , LED_RED1_Pin ,GPIO_PIN_SET );
		  HAL_GPIO_WritePin ( LED_YELLOW1_GPIO_Port , LED_YELLOW1_Pin ,GPIO_PIN_SET );
		  HAL_GPIO_WritePin ( LED_GREEN1_GPIO_Port , LED_GREEN1_Pin ,GPIO_PIN_SET );
		  if(is_button_pressed(0) == 1){
			  status = MAN_RED;
			  setTimer(1000);
		  }
		  if(timer1_flag == 1){
			  status = RED_GREEN;
			  setTimer(300);
		  }

		  break;
	case RED_GREEN:
		  HAL_GPIO_WritePin ( LED_RED_GPIO_Port , LED_RED_Pin ,GPIO_PIN_RESET );
		  HAL_GPIO_WritePin ( LED_YELLOW_GPIO_Port , LED_YELLOW_Pin ,GPIO_PIN_SET );
		  HAL_GPIO_WritePin ( LED_GREEN_GPIO_Port , LED_GREEN_Pin ,GPIO_PIN_SET );
		  HAL_GPIO_WritePin ( LED_RED1_GPIO_Port , LED_RED1_Pin ,GPIO_PIN_SET );
		  HAL_GPIO_WritePin ( LED_YELLOW1_GPIO_Port , LED_YELLOW1_Pin ,GPIO_PIN_SET );
		  HAL_GPIO_WritePin ( LED_GREEN1_GPIO_Port , LED_GREEN1_Pin ,GPIO_PIN_RESET );
		  if(is_button_pressed(0) == 1){
			  status = MAN_RED;
			  setTimer(1000);
		  }
		  if(timer1_flag == 1){
			  status = RED_YELLOW;
			  setTimer(200);

		  }

		  break;
	case RED_YELLOW:
		  HAL_GPIO_WritePin ( LED_RED_GPIO_Port , LED_RED_Pin ,GPIO_PIN_RESET );
		  HAL_GPIO_WritePin ( LED_YELLOW_GPIO_Port , LED_YELLOW_Pin ,GPIO_PIN_SET );
		  HAL_GPIO_WritePin ( LED_GREEN_GPIO_Port , LED_GREEN_Pin ,GPIO_PIN_SET );
		  HAL_GPIO_WritePin ( LED_RED1_GPIO_Port , LED_RED1_Pin ,GPIO_PIN_SET );
		  HAL_GPIO_WritePin ( LED_YELLOW1_GPIO_Port , LED_YELLOW1_Pin ,GPIO_PIN_RESET );
		  HAL_GPIO_WritePin ( LED_GREEN1_GPIO_Port , LED_GREEN1_Pin ,GPIO_PIN_SET );
		  if(is_button_pressed(0) == 1){
			  status = MAN_RED;
			  setTimer(1000);
		  }
		  if(timer1_flag == 1){
			  status = GREEN_RED;
			  setTimer(300);
		  }
		  break;
	case GREEN_RED:
		  HAL_GPIO_WritePin ( LED_RED_GPIO_Port , LED_RED_Pin ,GPIO_PIN_SET );
		  HAL_GPIO_WritePin ( LED_YELLOW_GPIO_Port , LED_YELLOW_Pin ,GPIO_PIN_SET );
		  HAL_GPIO_WritePin ( LED_GREEN_GPIO_Port , LED_GREEN_Pin ,GPIO_PIN_RESET );
		  HAL_GPIO_WritePin ( LED_RED1_GPIO_Port , LED_RED1_Pin ,GPIO_PIN_RESET );
		  HAL_GPIO_WritePin ( LED_YELLOW1_GPIO_Port , LED_YELLOW1_Pin ,GPIO_PIN_SET );
		  HAL_GPIO_WritePin ( LED_GREEN1_GPIO_Port , LED_GREEN1_Pin ,GPIO_PIN_SET );
		  if(is_button_pressed(0) == 1){
			  status = MAN_RED;
			  setTimer(1000);
		  }
		  if(timer1_flag == 1){
			  status = YELLOW_RED;
			  setTimer(200);
		  }
	case YELLOW_RED:
		  HAL_GPIO_WritePin ( LED_RED_GPIO_Port , LED_RED_Pin ,GPIO_PIN_SET );
		  HAL_GPIO_WritePin ( LED_YELLOW_GPIO_Port , LED_YELLOW_Pin ,GPIO_PIN_RESET );
		  HAL_GPIO_WritePin ( LED_GREEN_GPIO_Port , LED_GREEN_Pin ,GPIO_PIN_SET );
		  HAL_GPIO_WritePin ( LED_RED1_GPIO_Port , LED_RED1_Pin ,GPIO_PIN_RESET );
		  HAL_GPIO_WritePin ( LED_YELLOW1_GPIO_Port , LED_YELLOW1_Pin ,GPIO_PIN_SET );
		  HAL_GPIO_WritePin ( LED_GREEN1_GPIO_Port , LED_GREEN1_Pin ,GPIO_PIN_SET );
		  if(is_button_pressed(0) == 1){
			  status = MAN_RED;
			  setTimer(1000);
		  }
		  if(timer1_flag == 1){
			  status = RED_GREEN;
			  setTimer(300);
		  }
		  break;
	default:
			break;
	}
}
