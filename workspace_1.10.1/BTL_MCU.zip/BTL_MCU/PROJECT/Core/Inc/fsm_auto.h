/*
 * fsm_auto.h
 *
 *  Created on: Dec 11, 2022
 *      Author: ADMIN
 */

#ifndef INC_FSM_AUTO_H_
#define INC_FSM_AUTO_H_

#include "main.h"
#include "global.h"
#include "button.h"

void fsm_auto_run();

#endif /* INC_FSM_AUTO_H_ */
