/*
 * fsm_manual.h
 *
 *  Created on: Dec 11, 2022
 *      Author: ADMIN
 */
#ifndef INC_FSM_MANUAL_H_
#define INC_FSM_MANUAL_H_

#include "main.h"
#include "global.h"
#include "button.h"

void fsm_manual_run();

#endif /* INC_FSM_MANUAL_H_ */
