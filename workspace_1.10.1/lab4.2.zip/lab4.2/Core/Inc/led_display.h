/*
 * led_display.h
 *
 *  Created on: Nov 12, 2022
 *      Author: AdminPC
 */

#ifndef INC_LED_DISPLAY_H_
#define INC_LED_DISPLAY_H_

void led_red_toggle(void);
void led_yellow_toggle(void);
void led_green_toggle(void);


#endif /* INC_LED_DISPLAY_H_ */
